﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace converter
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private void octo(object sender, int strText)
        {
            if((sender as TextBox).Name!= "oct")
            oct.Text = Convert.ToString(strText, 8); //переводим в 8ричную систему счисления и заполняем соответсвующий текстбокс 
            
        }
        private void hexo(object sender, int strText)
        {
            if ((sender as TextBox).Name != "hex")
            hex.Text = Convert.ToString(strText, 16);//переводим в 16ричную систему счисления и заполняем соответсвующий текстбокс 
        }
        private void bino(object sender, int strText)
        {
            if ((sender as TextBox).Name != "bin")
                bin.Text = Convert.ToString(strText, 2);//переводим в 2ричную систему счисления и заполняем соответсвующий текстбокс 
        }
        private void deco(object sender, int strText)
        {

            dec.Text = Convert.ToString(strText, 10);//заполняем соответсвующий текстбокс 
        }
        
        private void TextChanged(object sender, EventArgs e)
        {
            int strText = 0;
            if ((sender as TextBox).Name == "dec" && (sender as TextBox).Text != "")   //проверяем в какое поле внесли число
            {
                strText = Convert.ToInt32((sender as TextBox).Text);
            }
            else if ((sender as TextBox).Name == "hex" && (sender as TextBox).Text != "") 
            {
                strText = Convert.ToInt32((sender as TextBox).Text, 16);
            }
            else if ((sender as TextBox).Name == "oct" && (sender as TextBox).Text != "")
            {
                strText = Convert.ToInt32((sender as TextBox).Text, 8);
            }
            else if ((sender as TextBox).Name == "bin" && (sender as TextBox).Text != "")
            {
                strText = Convert.ToInt32((sender as TextBox).Text, 2);
            }
            octo(sender, strText);
            hexo(sender, strText);
            bino(sender, strText);
            deco(sender, strText);
        }
    }
}
